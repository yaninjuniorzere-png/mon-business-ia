#!/usr/bin/env bash
set -euo pipefail

# Génère les fichiers Android natifs s'ils sont absents, puis compile l'APK.
if ! command -v flutter >/dev/null 2>&1; then
  echo "ERREUR : Flutter n'est pas installé ou n'est pas dans le PATH." >&2
  echo "Installe Flutter et Android Studio, puis relance ./build_apk.sh" >&2
  exit 1
fi

if [ ! -d android ]; then
  flutter create --platforms=android --org ci.monbusiness --project-name mon_business_ia .
fi

flutter pub get
flutter build apk --release

echo "APK généré : build/app/outputs/flutter-apk/app-release.apk"
