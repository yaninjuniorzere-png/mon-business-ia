# Mon Business IA — projet Flutter préparé pour Android

Ce dossier contient le code source Flutter du prototype et un script qui prépare les fichiers Android natifs puis compile l'APK.

## Fonctions présentes dans cette maquette
- Tableau de bord en FCFA
- Ajout de ventes et de dépenses
- Historique local des opérations
- Liste de stock et ajout de produits
- Assistant de démonstration basé sur les chiffres saisis
- Écran de présentation des offres Business et Premium

## Pré-requis
- Flutter installé et accessible dans le `PATH` (`flutter --version` doit fonctionner)
- Android Studio installé avec Android SDK et licences Android acceptées
- Une connexion Internet lors de la première préparation, pour télécharger les dépendances

## Générer l'APK Android

1. Décompresse ce ZIP sur un ordinateur.
2. Ouvre un terminal dans le dossier `mon_business_ia_mvp`.
3. Exécute :

   ```bash
   chmod +x build_apk.sh
   ./build_apk.sh
   ```

Le script crée automatiquement le dossier Android natif s'il manque, récupère les dépendances et lance la compilation en mode release.

L'APK sera ici :

`build/app/outputs/flutter-apk/app-release.apk`

Tu peux ensuite transférer ce fichier sur ton téléphone Android et l'installer. Android peut demander d'autoriser l'installation depuis cette source.

## Compiler manuellement

```bash
flutter create --platforms=android --org ci.monbusiness --project-name mon_business_ia .
flutter pub get
flutter build apk --release
```

Si le dossier `android/` existe déjà, ne relance pas la commande `flutter create` : exécute simplement `flutter pub get` puis `flutter build apk --release`.

## Limites importantes du prototype
- Les données restent en mémoire et disparaissent à la fermeture de l'application.
- L'assistant est une démonstration basée sur les chiffres saisis, pas une API d'intelligence artificielle connectée.
- Aucun paiement réel ni abonnement n'est activé.
- Il n'y a pas encore de compte utilisateur, de synchronisation Cloud ni de sauvegarde.

Les calculs du solde sont faits à partir des opérations saisies. Le solde affiché n'est pas présenté comme un bénéfice comptable certifié.

## Identifiant Android
Le script utilise `ci.monbusiness.mon_business_ia` comme identifiant d'application par défaut. Il peut être modifié dans la configuration Android après génération.

## Compilation depuis un téléphone Android (sans ordinateur)

Le dépôt peut être compilé dans le cloud avec GitHub Actions :
1. Crée un dépôt GitHub et téléverse le contenu de ce dossier en conservant les dossiers.
2. Attends que l'action « Construire APK Android » se termine (onglet Actions).
3. Ouvre l'exécution terminée, puis télécharge l'artefact « Mon-Business-IA-APK ».
4. Décompresse l'artefact pour récupérer `app-release.apk`.
