import 'package:flutter/material.dart';

void main() => runApp(const MonBusinessApp());

const forest = Color(0xFF075B38);
const green = Color(0xFF0B8F55);
const gold = Color(0xFFF2C45D);
const ink = Color(0xFF17231D);
const muted = Color(0xFF6C7971);
const canvas = Color(0xFFF5F7F3);

class MonBusinessApp extends StatelessWidget {
  const MonBusinessApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Mon Business IA',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: canvas,
        colorScheme: ColorScheme.fromSeed(seedColor: forest, primary: forest),
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: forest,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: Colors.grey.shade200),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: Colors.grey.shade200),
          ),
        ),
      ),
      home: const MainShell(),
    );
  }
}

class Operation {
  Operation(this.label, this.amount, this.isIncome, this.date);
  final String label;
  final int amount;
  final bool isIncome;
  final DateTime date;
}

class Product {
  Product(this.name, this.quantity, this.unit);
  final String name;
  int quantity;
  final String unit;
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int tab = 0;
  final List<Operation> operations = [
    Operation('Vente de riz', 75000, true, DateTime.now()),
    Operation('Transport', 12000, false, DateTime.now()),
    Operation('Achat marchandises', 8000, false, DateTime.now()),
  ];
  final List<Product> products = [
    Product('Riz parfumé', 12, 'sacs'),
    Product('Huile', 8, 'bidons'),
    Product('Sucre', 15, 'kg'),
  ];

  int get income => operations.where((o) => o.isIncome).fold(0, (s, o) => s + o.amount);
  int get expenses => operations.where((o) => !o.isIncome).fold(0, (s, o) => s + o.amount);
  int get balance => income - expenses;

  String money(int value) => '${value.toString().replaceAllMapped(
    RegExp(r'(\d)(?=(\d{3})+(?!\d))'), (m) => '${m[1]} ',
  )} FCFA';

  Future<void> addOperation(bool isIncome) async {
    final labelController = TextEditingController();
    final amountController = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(isIncome ? 'Ajouter une vente' : 'Ajouter une dépense'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: labelController, decoration: const InputDecoration(labelText: 'Motif ou produit')),
            const SizedBox(height: 12),
            TextField(
              controller: amountController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Montant en FCFA'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Enregistrer')),
        ],
      ),
    );
    final amount = int.tryParse(amountController.text.trim());
    if (ok == true && amount != null && amount > 0 && labelController.text.trim().isNotEmpty) {
      setState(() => operations.insert(0, Operation(labelController.text.trim(), amount, isIncome, DateTime.now())));
    }
    labelController.dispose();
    amountController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardPage(income: income, expenses: expenses, balance: balance, money: money,
        operations: operations, onAddSale: () => addOperation(true), onAddExpense: () => addOperation(false)),
      ActivityPage(operations: operations, money: money),
      StockPage(products: products, onChanged: () => setState(() {})),
      AssistantPage(income: income, expenses: expenses, balance: balance, money: money),
      const PremiumPage(),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: tab, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Accueil'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'Activité'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'Stock'),
          NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), label: 'Assistant IA'),
          NavigationDestination(icon: Icon(Icons.workspace_premium_outlined), label: 'Premium'),
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key, required this.income, required this.expenses, required this.balance,
    required this.money, required this.operations, required this.onAddSale, required this.onAddExpense});
  final int income, expenses, balance;
  final String Function(int) money;
  final List<Operation> operations;
  final VoidCallback onAddSale, onAddExpense;

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      Row(children: [
        Container(width: 44, height: 44, decoration: BoxDecoration(color: forest, borderRadius: BorderRadius.circular(14)),
          child: const Icon(Icons.storefront, color: gold, size: 27)),
        const SizedBox(width: 12),
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('MON BUSINESS IA', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1, color: forest)),
          Text('Votre commerce, mieux organisé', style: TextStyle(color: muted, fontSize: 12)),
        ])),
        const Icon(Icons.notifications_none, color: forest),
      ]),
      const SizedBox(height: 24),
      const Text('Bonjour ! 👋', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold, color: ink)),
      const Text('Voici le résumé de votre activité.', style: TextStyle(color: muted)),
      const SizedBox(height: 18),
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [forest, green]),
          borderRadius: BorderRadius.circular(22),
          boxShadow: [BoxShadow(color: forest.withOpacity(.18), blurRadius: 18, offset: const Offset(0, 8))],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Solde provisoire du jour', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 8),
          Text(money(balance), style: const TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          const Text('Recettes enregistrées moins dépenses enregistrées', style: TextStyle(color: Colors.white70, fontSize: 11)),
        ]),
      ),
      const SizedBox(height: 14),
      Row(children: [
        Expanded(child: MetricCard(title: 'Ventes', amount: money(income), icon: Icons.trending_up, color: green)),
        const SizedBox(width: 10),
        Expanded(child: MetricCard(title: 'Dépenses', amount: money(expenses), icon: Icons.trending_down, color: Colors.redAccent)),
      ]),
      const SizedBox(height: 16),
      Row(children: [
        Expanded(child: FilledButton.icon(onPressed: onAddSale, icon: const Icon(Icons.add_shopping_cart), label: const Text('Ajouter une vente'), style: FilledButton.styleFrom(backgroundColor: forest, padding: const EdgeInsets.symmetric(vertical: 15)))),
      ]),
      const SizedBox(height: 9),
      OutlinedButton.icon(onPressed: onAddExpense, icon: const Icon(Icons.add), label: const Text('Ajouter une dépense'), style: OutlinedButton.styleFrom(foregroundColor: forest, padding: const EdgeInsets.symmetric(vertical: 14))),
      const SizedBox(height: 22),
      const Text('Dernières opérations', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: ink)),
      const SizedBox(height: 8),
      ...operations.take(4).map((o) => OperationTile(operation: o, money: money)),
      const SizedBox(height: 18),
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: const Color(0xFFFFF4D8), borderRadius: BorderRadius.circular(18)),
        child: const Row(children: [
          Icon(Icons.lightbulb_outline, color: Color(0xFF9A6B00)),
          SizedBox(width: 10),
          Expanded(child: Text('Astuce : notez chaque vente et chaque dépense pour connaître votre résultat réel.', style: TextStyle(color: ink, fontSize: 13))),
        ]),
      )
    ],
  );
}

class MetricCard extends StatelessWidget {
  const MetricCard({super.key, required this.title, required this.amount, required this.icon, required this.color});
  final String title, amount;
  final IconData icon;
  final Color color;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.black.withOpacity(.04))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: color),
      const SizedBox(height: 7),
      Text(title, style: const TextStyle(color: muted, fontSize: 12)),
      const SizedBox(height: 4),
      FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(amount, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: ink))),
    ]),
  );
}

class OperationTile extends StatelessWidget {
  const OperationTile({super.key, required this.operation, required this.money});
  final Operation operation;
  final String Function(int) money;
  @override
  Widget build(BuildContext context) => ListTile(
    contentPadding: EdgeInsets.zero,
    leading: CircleAvatar(backgroundColor: operation.isIncome ? const Color(0xFFE3F4E9) : const Color(0xFFFFE8E8),
      child: Icon(operation.isIncome ? Icons.arrow_downward : Icons.arrow_upward, color: operation.isIncome ? green : Colors.red)),
    title: Text(operation.label, style: const TextStyle(fontWeight: FontWeight.w600)),
    subtitle: Text(operation.isIncome ? 'Recette' : 'Dépense'),
    trailing: Text('${operation.isIncome ? '+' : '-'}${money(operation.amount)}',
      style: TextStyle(fontWeight: FontWeight.bold, color: operation.isIncome ? green : Colors.red, fontSize: 12)),
  );
}

class ActivityPage extends StatelessWidget {
  const ActivityPage({super.key, required this.operations, required this.money});
  final List<Operation> operations;
  final String Function(int) money;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Mon activité')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const Text('Historique des opérations', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: ink)),
      const SizedBox(height: 8),
      const Text('Retrouvez les ventes et dépenses enregistrées sur cet appareil.', style: TextStyle(color: muted)),
      const SizedBox(height: 16),
      ...operations.map((o) => OperationTile(operation: o, money: money)),
    ]),
  );
}

class StockPage extends StatefulWidget {
  const StockPage({super.key, required this.products, required this.onChanged});
  final List<Product> products;
  final VoidCallback onChanged;
  @override
  State<StockPage> createState() => _StockPageState();
}
class _StockPageState extends State<StockPage> {
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Mon stock')),
    floatingActionButton: FloatingActionButton.extended(
      backgroundColor: forest, foregroundColor: Colors.white,
      onPressed: () async {
        final name = TextEditingController();
        final qty = TextEditingController();
        final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
          title: const Text('Ajouter un produit'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Nom du produit')),
            const SizedBox(height: 10),
            TextField(controller: qty, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Quantité')),
          ]),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Ajouter'))],
        ));
        final q = int.tryParse(qty.text);
        if (ok == true && name.text.trim().isNotEmpty && q != null && q >= 0) {
          setState(() => widget.products.add(Product(name.text.trim(), q, 'unités')));
          widget.onChanged();
        }
        name.dispose(); qty.dispose();
      },
      icon: const Icon(Icons.add), label: const Text('Ajouter'),
    ),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const Text('Vos marchandises', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: ink)),
      const SizedBox(height: 8),
      const Text('Suivez les quantités disponibles.', style: TextStyle(color: muted)),
      const SizedBox(height: 14),
      ...widget.products.map((p) => Card(color: Colors.white, child: ListTile(
        leading: const CircleAvatar(backgroundColor: Color(0xFFE5F3E9), child: Icon(Icons.inventory_2, color: forest)),
        title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('Stock disponible'),
        trailing: Text('${p.quantity} ${p.unit}', style: const TextStyle(fontWeight: FontWeight.bold, color: forest)),
      ))),
    ]),
  );
}

class AssistantPage extends StatefulWidget {
  const AssistantPage({super.key, required this.income, required this.expenses, required this.balance, required this.money});
  final int income, expenses, balance;
  final String Function(int) money;
  @override
  State<AssistantPage> createState() => _AssistantPageState();
}
class _AssistantPageState extends State<AssistantPage> {
  final controller = TextEditingController();
  final messages = <Map<String, String>>[
    {'from': 'ai', 'text': 'Bonjour ! Je suis votre assistant de gestion. Posez-moi une question sur vos chiffres ou votre commerce.'}
  ];
  void send() {
    final question = controller.text.trim();
    if (question.isEmpty) return;
    setState(() {
      messages.add({'from': 'user', 'text': question});
      final q = question.toLowerCase();
      String answer;
      if (q.contains('recette') || q.contains('vente')) {
        answer = 'Vos recettes enregistrées sont de ${widget.money(widget.income)}. Vérifiez que toutes vos ventes du jour sont saisies.';
      } else if (q.contains('dépense')) {
        answer = 'Vos dépenses enregistrées sont de ${widget.money(widget.expenses)}. Pensez à noter aussi le transport, les achats et les petits frais.';
      } else if (q.contains('gagn') || q.contains('bénéfice') || q.contains('solde')) {
        answer = 'Votre solde provisoire est de ${widget.money(widget.balance)} (recettes enregistrées moins dépenses enregistrées). Ce n’est pas forcément le bénéfice comptable final.';
      } else {
        answer = 'Je peux déjà résumer vos recettes (${widget.money(widget.income)}), vos dépenses (${widget.money(widget.expenses)}) et votre solde provisoire (${widget.money(widget.balance)}). La connexion à une véritable IA sera ajoutée dans la prochaine étape.';
      }
      messages.add({'from': 'ai', 'text': answer});
      controller.clear();
    });
  }
  @override
  void dispose() { controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Mon assistant IA'), subtitle: const Text('Conseils pour votre commerce')),
    body: Column(children: [
      Expanded(child: ListView.builder(padding: const EdgeInsets.all(16), itemCount: messages.length, itemBuilder: (ctx, i) {
        final m = messages[i]; final isUser = m['from'] == 'user';
        return Align(alignment: isUser ? Alignment.centerRight : Alignment.centerLeft, child: Container(
          margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(14), constraints: const BoxConstraints(maxWidth: 310),
          decoration: BoxDecoration(color: isUser ? const Color(0xFFE3F1E6) : Colors.white, borderRadius: BorderRadius.circular(17)),
          child: Text(m['text']!, style: const TextStyle(color: ink)),
        ));
      })),
      SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(12, 8, 12, 12), child: Row(children: [
        Expanded(child: TextField(controller: controller, onSubmitted: (_) => send(), decoration: const InputDecoration(hintText: 'Écrivez votre question...'))),
        const SizedBox(width: 8),
        IconButton.filled(onPressed: send, icon: const Icon(Icons.send), style: IconButton.styleFrom(backgroundColor: forest, foregroundColor: Colors.white)),
      ]))),
    ]),
  );
}

class PremiumPage extends StatelessWidget {
  const PremiumPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Passez à Premium')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const Icon(Icons.workspace_premium, size: 60, color: Color(0xFFD5A62E)),
      const SizedBox(height: 10),
      const Text('Faites grandir votre commerce', textAlign: TextAlign.center, style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold, color: ink)),
      const SizedBox(height: 8),
      const Text('Des outils plus puissants pour mieux comprendre vos résultats.', textAlign: TextAlign.center, style: TextStyle(color: muted)),
      const SizedBox(height: 20),
      _plan('Business', '1 500 FCFA / mois', ['Rapports détaillés', 'Gestion du stock', 'Assistant IA avec quota étendu']),
      const SizedBox(height: 12),
      _plan('Premium', '3 000 FCFA / mois', ['Toutes les fonctions Business', 'Analyse avancée', 'Plusieurs activités et utilisateurs']),
      const SizedBox(height: 14),
      const Text('Démo uniquement : aucun paiement réel n’est activé dans cette version.', textAlign: TextAlign.center, style: TextStyle(color: muted, fontSize: 12)),
    ]),
  );
  Widget _plan(String name, String price, List<String> features) => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: name == 'Premium' ? gold : Colors.black12, width: name == 'Premium' ? 2 : 1)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(name, style: const TextStyle(fontWeight: FontWeight.bold, color: forest, fontSize: 18)),
      const SizedBox(height: 4),
      Text(price, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 22, color: ink)),
      const SizedBox(height: 10),
      ...features.map((f) => Padding(padding: const EdgeInsets.only(bottom: 7), child: Row(children: [
        const Icon(Icons.check_circle, color: green, size: 18), const SizedBox(width: 8), Expanded(child: Text(f)),
      ]))),
    ]),
  );
}
